<?php 

/**
* 
*/
class Admin extends CI_Controller
{
	
	function __construct()
	{
		# code...
		parent::__construct();
		if (!$this->permission->is_loggedin())
		redirect();
	}
	public function index($value='')
	{
		# code...
		$data['site_title'] = 'Admin';
		$this->template->load('admin','admin/index',$data);
	}

	public function create_zip()
	{

    // Load the DB utility class
    $this->load->dbutil();

    // Backup your entire database and assign it to a variable
    $backup =& $this->dbutil->backup();

    $fileName = 'anime-video-backup-'.date('Y-m-d H:i:s').'.zip';
    // Load the file helper and write the file to your server
    //$this->load->helper('file');
    //write_file(UPLOADPATH.'/admin/'.$fileName, $backup);

    // Load the download helper and send the file to your desktop
    $this->load->helper('download');
    force_download($fileName, $backup);

	}
}