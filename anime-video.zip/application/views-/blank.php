<div class="col-sm-12 col-md-12 col-lg-12 blank <?php echo isset($class) ? $class : '';?>">
	
<?php echo isset($content) ? $content : '';?>
</div>

