<div class="row contact">
<div class="col-md-9 post-content">
	<div class="panel">
		<div class="panel-heading"><h3>About us!</h3></div>
		<div class="panel-body">
		<?php echo isset($content) ? $content : '';   ?>
			
		</div>
	</div>
</div>
<div class="col-md-3 post-sidebar">
	
</div>
</div>