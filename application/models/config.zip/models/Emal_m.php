<?php 

/**
* 
*/
class Emal_m extends CI_Model
{


	
	function __construct()
	{
		parent::__construct();
		//$this->load->library('email');
	}
	public function verify_email($toemail=false,$code=false)
	{
		# code...
		if($toemail && $code){
			$myemail = 'info@coloftech.com';
			//config email settings
       	
       	//config email settings
        $config['protocol'] = 'smtp';
        $config['smtp_host'] = 'mail.coloftech.com';
        $config['smtp_crypto'] = 'ssl';
        $config['smtp_port'] = '465';
        $config['smtp_user'] = $myemail;
        $config['smtp_pass'] = 'hearts012';  //sender's password
        $config['mailtype'] = 'html';
        $config['charset'] = 'iso-8859-1';
        $config['wordwrap'] = 'TRUE';
        $config['newline'] = "\r\n"; 
        
        $this->load->library('email', $config);
		$this->email->initialize($config);
	
		$subject = 'Verification';
		$message = 'This is your verification code: <b>'.$code .'</b> <br /> Enter this code to registration area.';
//send email
        $this->email->from($myemail,'COLOFTECH: Onlive Review Center');
        $this->email->to($toemail);
        $this->email->subject($subject);
        $this->email->message($message);
        
        $this->email->send();

		}
	}
}