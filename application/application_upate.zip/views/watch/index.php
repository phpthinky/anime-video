<div class="col-md-12 post-index">
	
<div class="col-md-9">

		
<?php if(isset($video) && isset($video->title)): ?>

<div class="panel">
	<div class="panel-body">
	<div class="video-content" style="display:block;">
		
		<?php echo $video->embed;?>
	</div>
	<div class="video-title" style="display:block;"><h4><?php echo strtoupper($video->title) ;?> 
	<?php if ($this->permission->is_loggedin() == true): ?><a href="<?=site_url("video/info/$video->video_id")?>" class="btn"><i class="fa fa-edit">
                          </i></a><?php endif ?></h4></div>

	</div>

</div>

<div class="panel">
	<div class="panel-body">
	<div class="video-content" style="display:block;">
		<?php if (isset($mirrors)): ?>
			<?php //var_dump($mirrors) ?>
			<?php if (is_array($mirrors)): ?>

				<h5><a href="<?=site_url('watch/v/'.$video->slug) ?>">DEFAULT</a></h5>
				<?php $i=1; foreach ($mirrors as $m): ?>
					<?php 
					$mirror = $m->source_id;
					switch ($mirror) {
						case '1':
							# code...
							$m_name = 'MP4UPLOAD';
							break;

						case '2':
							# code...
							$m_name = 'YOUTUBE';
							break;

						case '3':
							# code...
							$m_name = 'FACEBOOK';
							break;

						case '4':
							# code...
							$m_name = 'DAILYMOTION';
							break;

						case '5':
							# code...
							$m_name = 'OPENLOAD';
							break;

						case '6':
							# code...
							$m_name = 'GOOGLE DRIVE';
							break;

						
						default:
							# code...
							$m_name = 'DEFAULT';
							break;
					} ?>
					
				<h5><a href="?mirror=<?=$m->source_id?>">MIRROR <?=$i?> (<?=$m_name?>)</a></h5>
				<?php $i++; endforeach ?>
			<?php endif ?>
		<?php endif ?>
		
	</div>

	</div>

</div>
<?php else: ?>
	
<?php endif ?>




<style type="text/css">

</style>


<script type="text/javascript">
	$(document).ready(function() {
    $('iframe').removeAttr('width');
    $('iframe').removeAttr('height');
});
</script>








</div>
<div class="col-md-3 side-bar">
	<div class="panel panel-search">
	<div class="panel-body" style="padding: 0;">
		<form action="<?=site_url('home/search');?>"><input class="form-control" placeholder="Search" id="search" name="q" /><button type="submit" class="btn btn-info pull-right" style="margin-left:-48px;z-index:9999999;position:absolute;">GO</button></form>
		</div>
	</div>
	<?php if (isset($video)  && isset($video->title)): ?>
		
	<div class="panel">
		<div class="panel-heading"><h4>SYPNOSIS</h4></div>
		<div class="panel-body">
			<p>
			<label><?php echo strtoupper($video->title) ?></label> -
				<?php echo !empty($video->sypnosis) ? $video->sypnosis : 'No information.'; ?>
				<div class="fb-share-button" data-href="<?=$link?>" data-layout="button_count" data-size="small" data-mobile-iframe="true"><a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=<?=urlencode(site_url($link))?>&amp;src=sdkpreparse" class="fb-xfbml-parse-ignore">Share</a></div>
			</p>

		</div>


	</div>

	<?php if (isset($playlist)): ?>
		<div class="panel" style="padding-bottom:10px;">
		<div class="panel-heading"><h4>PLAY LIST</h4></div>
		<div class="panel-body" style="max-height:300px;overflow:auto;">
			<ul class="recent-post">
				<?php echo $playlist ?>
			</ul>
		</div>


	</div>	
	<?php endif ?>
	<div class="panel">
		<div class="panel-heading"><h4>RATING</h4></div>
		<div class="panel-body">
			<ul class="recent-post">
				<?php //echo $this->auto_m->recent_post(5); ?>
			</ul>
		</div>


	</div>



	<?php endif ?>
	<div class="panel">
		<div class="panel-heading"><h4>MESSAGES </h4>
			
		</div>
		<div class="panel-body">
		<p>
        
    	Want to have your own video portal. Message me now.<br/>Currently supported video youtube, mp4upload, facebook video

      	</p>
      <p>
    	Contact: roy.rita@coloftech.com</p>
      <!-- p>
          <div class="fb-page" data-href="https://www.facebook.com/coloftech/" data-tabs="about" data-width="350" data-small-header="true" data-adapt-container-width="true" data-hide-cover="true" data-show-facepile="true"><blockquote cite="https://www.facebook.com/coloftech/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/coloftech/">Coloftech - State of the Art &amp; Technology</a></blockquote></div>
      </p -->
		</div>
	</div>

</div>
</div>
