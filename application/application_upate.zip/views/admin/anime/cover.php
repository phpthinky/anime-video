<div class="panel panel-info">
<div class="panel-heading"><h3>Cover page</h3></div>
	<div class="panel-body">
		<form class="form">
		<div class="col-md-4">
			<div class="form-group">
			<div class="hidden">
				<input type="hidden" name="video_id" id="video_id" value="<?= isset($cover_page->video_id) ? $cover_page->video_id : '' ; ?>">
				<input type="hidden" name="cover_thumbnail" id="cover_thumbnail" value="<?= isset($cover_page->thumbnail) ? $cover_page->thumbnail : (isset($video_info->thumbnail) ? $video_info->thumbnail : '' ) ; ?>">
			</div>
				<label class="title">Cover Photo <a class="btn" href="javascript:void(0)"><i class="fa fa-camera"></i></a></label>
				<?php if(isset($cover_page->thumbnail)): ?>

				<img class="previewimg" src="<?=$cover_page->thumbnail ?>" style="width:100%;"></img>
				<?php else:  ?>
					<?php if (isset($video_info->thumbnail)): ?>
						<img src="<?=$video_info->thumbnail?>"  style="width:100%;">
						<?php else: ?>
						<img class="previewimg" src="<?=base_url('public/images/default-img.jpg')?>" style="width:100%;"></img>
					<?php endif ?>
				<?php endif ?>

			</div>
			</div>
		<div class="col-md-8">
			<div class="form-group">
				<label class="title">Title</label>
				<input type="text" name="cover_title" id="cover_title" class="form-control" value="<?= isset($cover_page->title) ? $cover_page->title : (isset($video_info->title) ? $video_info->title : '' ) ; ?>">
			</div>

			<div class="form-group">
				<label class="title">Synopsis</label>
				<textarea class="form-control" name="cover_synopsis" id="cover_synopsis" rows="8"><?= isset($cover_page->synopsis) ? $cover_page->synopsis : (isset($video_info->sypnosis) ? $video_info->sypnosis : '' ) ; ?></textarea>
			</div>

			<div class="form-group">
				<label class="title">Genre</label>
				<textarea class="form-control" name="cover_synopsis" id="cover_genre" rows="8"><?= isset($cover_page->genre) ? $cover_page->genre : '' ; ?></textarea>
			</div>

			<div class="form-group">
				<label class="title">&nbsp;</label>
				<button class="btn btn-info"><i class="fa fa-save"></i> Update</button>
			</div>
			
		</div>
			

		</form>
	</div>
</div>