<div class="wrapper site-wrapper">
	<div class="container site-container">
		<h4>Contact</h4>

		<div class="row contact">
			<div class="col-md-8">
				<div class="panel">
					<div class="panel-heading">
						
					</div>
					<div class="panel-body">
						<div class="col-md-12">
							<div class="form-responsive">
								<form class="form form-horizontal">
									<div class="form-group">
										<label for='email'>Email</label><input type="text" name="email" class="form-control" />
									</div>
									<div class="form-group">
										<label for='email'>Subject</label><input type="text" name="email" class="form-control" />
									</div>

									<div class="form-group">
										<label for='email'>Email</label>
										<textarea class="form-control" name="message" id="message" rows="8"></textarea>
									</div>

									<div class="form-group">

										<button class="btn btn-info">Submit</button>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="col-md-4">
				<div class="panel">
					<div class="panel-heading">Contact address</div>
					<div class="panel-body">
						<p>Company name: Bohol Island State University</p>
						<p>Address: Zamora, Bilar, Bohol, Phillippines 6317</p>
						
					</div>
				</div>

			</div>
		</div>
	</div>
</div>