<div class="col-md-12 post-index">
	
<div class="col-md-9">

		
<?php if(isset($video) && isset($video->title)): ?>

<div class="panel">
	<div class="panel-body">
	<div class="video-content" style="display:block;">
		
		<?php echo $video->embed;?>
	</div>
	<div class="video-title" style="display:block;"><h4><?php echo strtoupper($video->title) ;?></h4></div>

	</div>

</div>
<?php else: ?>
	
<?php endif ?>




<style type="text/css">
	.watch-mobile{
		width: 100%;
		height: 100%;
		min-width: 200px;
		min-height: 200px;
	}

	.watch-pc{
		width: 100%;
		height: 100%;
		min-width: 650px;
		min-height: 400px;
	}
</style>


<script type="text/javascript">
	$(document).ready(function() {
    $('iframe').removeAttr('width');
    $('iframe').removeAttr('height');
});
</script>








</div>
<div class="col-md-3 side-bar">
	<div class="panel panel-search">
	<div class="panel-body" style="padding: 0;">
		<form action="<?=site_url('home/search');?>"><input class="form-control" placeholder="Search" id="search" name="q" /><i class="fa fa-search pul"></i></form>
		</div>
	</div>
	<?php if (isset($video)  && isset($video->title)): ?>
		
	<div class="panel">
		<div class="panel-heading"><h4>SYPNOSIS</h4></div>
		<div class="panel-body">
			<p>
			<label><?php echo strtoupper($video->title) ?></label> -
				<?php echo !empty($video->sypnosis) ? $video->sypnosis : 'No information.'; ?>
			</p>
		</div>


	</div>

	<?php if (isset($playlist)): ?>
		<div class="panel">
		<div class="panel-heading"><h4>PLAY LIST</h4></div>
		<div class="panel-body">
			<ul class="recent-post">
				<?php echo $playlist ?>
			</ul>
		</div>


	</div>	
	<?php endif ?>
	<div class="panel">
		<div class="panel-heading"><h4>RATING</h4></div>
		<div class="panel-body">
			<ul class="recent-post">
				<?php //echo $this->auto_m->recent_post(5); ?>
			</ul>
		</div>


	</div>



	<?php endif ?>
	<div class="panel">
		<div class="panel-heading"><h4>SHARE US NOW </h4>
			
		</div>
		<div class="panel-body">
		<p>
        
    	Want to have your own video portal. Message me now.<br/>Currently supported video youtube, mp4upload, facebook video

      	</p>
      <p>
    	Contact: roy.rita@coloftech.com</p>
      <!-- p>
          <div class="fb-page" data-href="https://www.facebook.com/coloftech/" data-tabs="about" data-width="350" data-small-header="true" data-adapt-container-width="true" data-hide-cover="true" data-show-facepile="true"><blockquote cite="https://www.facebook.com/coloftech/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/coloftech/">Coloftech - State of the Art &amp; Technology</a></blockquote></div>
      </p -->
		</div>
	</div>

</div>
</div>
