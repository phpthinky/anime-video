<?php 

/**
* 
*/
class Watch extends CI_Controller
{
	
	function __construct()
	{
		# code...
		parent::__construct();
		$this->load->model('video_m');
	}
	public function v($url='')
	{
		
		$video = $this->video_m->getVideo($url);
		if($video){

			$this->load->model('statistics');
			$views = $this->statistics->saveViews($video[0]->video_id);

			if($has_parent = $this->video_m->getParent($video[0]->video_id)){
				$playlist = $this->video_m->getPlaylist($has_parent);
				$list = '';

				//var_dump($playlist);
				//exit();
				foreach ($playlist as $key) {
					# code...
					$info = '';
					$info = $this->video_m->getVideo($key->video_id);
					$info = $info[0];
					//var_dump($info);
					$list .= "<li><a href='$info->slug' >$info->title ($info->episode_number)</a></li>";
				}

					$info = '';
					$info = $this->video_m->getVideo($has_parent);
					$info = $info[0];
				//$list .= "<li><a href='$info->slug' >$info->title</a></li>";
				$data['playlist'] = $list;
			}elseif($has_child = $this->video_m->getChild($video[0]->video_id)){

				//$playlist = $this->video_m->getPlaylist($has_child);
				$list = '';
				foreach ($has_child as $key) {
					# code...
					$info = '';
					$info = $this->video_m->getVideo($key->video_id);
					$info = $info[0];
					//var_dump($info);
					$list .= "<li><a href='$info->slug' >$info->title ($info->episode_number)</a></li>";
				}

					$info = '';
					$info = $this->video_m->getVideo($video[0]->video_id);
					$info = $info[0];
				//$list .= "<li><a href='$info->slug' >$info->title</a></li>";
				$data['playlist'] = $list;
			}

		}
		//var_dump($video);
		//exit();
		$data['video'] = isset($video[0]) ? $video[0] : false ;
		$data['site_title'] = 'Watch';
		$this->template->load('default','watch/index',$data);
	}public function new_upload($value='')
	{
		# code...
		$data['list_video'] = $this->video_m->list_new_upload();
		$data['site_title'] = 'List of all new uploaded videos';
		$this->template->load('default','watch/video',$data) ;
	}

}