<?php 

/**
* 
*/
class Video extends CI_Controller
{
	
	function __construct()
	{
		# code...
		parent::__construct();
		if (!$this->permission->is_loggedin())
		redirect();

		$this->load->model('video_m');

	}
	public function index($value='')
	{
		# code...
		$data['site_title'] = 'Add new of video.';
		$this->template->load('admin','admin/anime/new',$data);
	}
	public function info($video_id=0)
	{
		# code...
		$data['video_id'] = $video_id;
		$info = $this->video_m->getVideo($video_id);
		//var_dump($info);
		if($videos = $this->video_m->getEpisodes($video_id)){

		}else{
			$parent = $this->video_m->getParent($video_id);
			$videos = $this->video_m->getEpisodes($parent);
		}
//var_dump($videos);exit();
		$data['total_episodes'] = count($videos);
		$data['list_episodes'] = $videos;

		$data['infos'] = isset($info[0]) ? $info[0] : false;

		$data['site_title'] = 'Information';
		$this->template->load('admin','admin/anime/info',$data);
	}
	public function new_video($value='')
	{
		# code...

		$data['site_title'] = 'Add new video';
		$this->template->load('admin','admin/anime/new',$data);

	}

	public function add($video_id='')
	{
		# code...
		//$data['video_id'] = 11;
		$data['site_title'] = 'Add video';
		$this->template->load('admin','admin/anime/add',$data);
	}
	public function saveepisode()
	{
		

		# code...
		if($this->input->post()){
		$post = $this->input->post();
		$obj = (object)$post;

		if(empty($obj->txtepisodetitle)){
			echo json_encode(array('stats'=>false,'msg'=>'Video title is required.'));
			exit();
		}
		if(empty($obj->txtlink) && empty($obj->txtembed)){

			echo json_encode(array('stats'=>false,'msg'=>'Video source url or embed is required.'));
			exit();
		}

		if($obj->videosource == 0){

			echo json_encode(array('stats'=>false,'msg'=>'No video source selected.'));
			exit();
		}
		$embed = $obj->txtembed;
		$thumbnail = '';
		if(!empty($obj->txtlink)){
			if($obj->videosource == 1){
				$link_id = str_replace('https://www.mp4upload.com/', '', $obj->txtlink);
			$embed = '<iframe class="watch watch-pc" src="https://www.mp4upload.com/embed-'.$link_id.'.html"></iframe>';

			}
			if($obj->videosource == 2){
				$link_id = str_replace('https://youtu.be/', '', $obj->txtlink);
				if($link_id != $obj->txtlink){
					$link_id = strstr($link_id, '?', true) ? : $link_id;
				}
				if($link_id == $obj->txtlink){

					$link_id = str_replace('https://www.youtube.com/watch?', '', $link_id);
					parse_str($link_id,$arr);
					$link_id = $arr['v'];
				}

			$embed = '<iframe class="watch watch-pc" src="https://www.youtube.com/embed/'.$link_id.'" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>';
			$thumbnail =  "https://img.youtube.com/vi/$link_id/hqdefault.jpg";
			}

			if($obj->videosource == 3){
				$link_id = urlencode($obj->txtlink);

			$embed = '<iframe class="watch watch-pc" src="https://www.facebook.com/plugins/video.php?href='.$link_id.'" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allowFullScreen="true"></iframe>';

			}
			
			}
			$input = array(
				'title'=>$obj->txtepisodetitle,
				'slug'=>$this->slug->create($obj->txtepisodetitle.' no '.$obj->txtepisodenumber),
				'tags'=>$obj->txttags,
				'embed'=>$embed,
				'link'=>$obj->txtlink,
				'thumbnail'=>$thumbnail,	
				'source_id'=>$obj->videosource,			
				'date_added'=>date('Y:m:d h:j:s'),
				'episode_number'=>$obj->txtepisodenumber,
				'sypnosis'=>$obj->syspnosis
				);
			$is_added = $this->video_m->save($input);
			if($is_added){
				$input2 = array(
					'video_id'=>$is_added,
					'parent_video_id'=>$obj->video_id,
					'source_id'=>$obj->videosource,
					'episode'=>$obj->txtepisodenumber
					);
				$saveEp = $this->video_m->addEpisodes($input2);
				echo json_encode(array('stats'=>true,'msg'=>"Video added successfully.",'video_id'=>$is_added));
			}else{
				echo json_encode(array('stats'=>false,'msg'=>"Video is not added.",'video_id'=>$is_added));
			}


		exit();
		}

		echo $this->noinput();
	}
	public function noinput()
	{
		# code...
		return  json_encode(array('stats'=>false,'msg'=>'No input received'));
	}
	public function savevideo()
	{
		# code...
		if($this->input->post()){
		$post = $this->input->post();
		$obj = (object)$post;

		if(empty($obj->txttitle)){
			echo json_encode(array('stats'=>false,'msg'=>'Video title is required.'));
			exit();
		}
		if(empty($obj->txtlink) && empty($obj->txtembed)){

			echo json_encode(array('stats'=>false,'msg'=>'Video source url or embed is required.'));
			exit();
		}

		if($obj->videosource == 0){

			echo json_encode(array('stats'=>false,'msg'=>'No video source selected.'));
			exit();
		}
		$embed = $obj->txtembed;
		if(!empty($obj->txtlink)){
			if($obj->videosource == 1){
				$link_id = str_replace('https://www.mp4upload.com/', '', $obj->txtlink);
			$embed = '<iframe class="watch watch-pc" src="https://www.mp4upload.com/embed-'.$link_id.'.html"></iframe>';

			}
			if($obj->videosource == 2){
				$link_id = str_replace('https://youtu.be/', '', $obj->txtlink);
				if($link_id != $obj->txtlink){
					$link_id = strstr($link_id, '?', true) ? : $link_id;
				}
				if($link_id == $obj->txtlink){

					$link_id = str_replace('https://www.youtube.com/watch?', '', $link_id);
					parse_str($link_id,$arr);
					$link_id = $arr['v'];
				}

			$embed = '<iframe class="watch watch-pc" src="https://www.youtube.com/embed/'.$link_id.'" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>';

			}

			if($obj->videosource == 3){
				$link_id = urlencode($obj->txtlink);

			$embed = '<iframe class="watch watch-pc" src="https://www.facebook.com/plugins/video.php?href='.$link_id.'" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allowFullScreen="true"></iframe>';

			}
			
			}
			$input = array(
				'title'=>$obj->txttitle,
				'slug'=>$this->slug->create($obj->txttitle.' no '.$obj->episodenumber),
				'tags'=>$obj->txttags,
				'embed'=>$embed,
				'link'=>$obj->txtlink,
				'source_id'=>$obj->videosource,
				'thumbnail'=>$obj->thumbnail,				
				'date_added'=>date('Y:m:d h:j:s'),
				'video_type'=>$obj->videotype,
				'episode_number'=>$obj->episodenumber,
				'sypnosis'=>$obj->sypnosis
				);
			$is_added = $this->video_m->save($input);
			if($is_added){

				$input2 = array(
					'video_id'=>$is_added,
					'parent_video_id'=>$is_added,
					'source_id'=>$obj->videosource,
					'episode'=>$obj->episodenumber
					);
				$saveEp = $this->video_m->addEpisodes($input2);
				echo json_encode(array('stats'=>true,'msg'=>"Video added successfully.",'video_id'=>$is_added));
			}else{
				echo json_encode(array('stats'=>false,'msg'=>"Video is not added.",'video_id'=>$is_added));
			}

		exit();
		}
			echo json_encode(array('stats'=>false,'msg'=>'No input received.'));

	}
	public function ytthumb()
	{
		# code...
		if($this->input->post()){

		$post = $this->input->post();
		$obj = (object)$post;
			if($obj->videosource == 2){
				$link_id = str_replace('https://youtu.be/', '', $obj->txtlink);
				if($link_id != $obj->txtlink){
					$link_id = strstr($link_id, '?', true) ? : $link_id;
				}
				if($link_id == $obj->txtlink){

					$link_id = str_replace('https://www.youtube.com/watch?', '', $link_id);
					parse_str($link_id,$arr);
					$link_id = $arr['v'];
				}

				echo "https://img.youtube.com/vi/$link_id/hqdefault.jpg";
			}

			exit();
		}
	}

	public function upload(){

		if($this->input->post()) {

			$target_dir = UPLOADPATH."/uploads/";
			$target_file = $target_dir . basename($_FILES["upload"]["name"]);
			$uploadOk = 1;
			$error = '';

    		$check = getimagesize($_FILES["upload"]["tmp_name"]);
		    if($check !== false) {
		        //$error .= "File is an image - " . $check["mime"] . ".";
		        $uploadOk = 1;
		    } else {
		        $error .= "File is not an image.<br />";
		        $uploadOk = 0;
		    }

		    // Check if file already exists
			if (file_exists($target_file)) {
			    $error .= "Sorry, file already exists.<br />";
			    $uploadOk = 0;
			}
			// Check file size
			if ($_FILES["upload"]["size"] > 500000) {
			    $error .= "Sorry, your file is too large.<br />";
			    $uploadOk = 0;
			}
			if($uploadOk == 0){
				echo json_encode(array('stats'=>false,'msg'=>$error));
			}else{
				 if (move_uploaded_file($_FILES["upload"]["tmp_name"], $target_file)) {
			       
				echo json_encode(array('stats'=>true,'msg'=>base_url('public/uploads/'.basename( $_FILES["upload"]["name"]))));
			    } else {
			        
				echo json_encode(array('stats'=>false,'msg'=>"Sorry, there was an error uploading your file."));

			    }
			}
		}



	}

	public function search($value='')
	{
		# code...
		if($this->input->post()){
			$q = $this->input->post('q');
			$slug = $this->slug->create($q);

			$keywords = explode('-', $slug);
			$infos = false;
			$keys = false;
			foreach ($keywords as $key) {
				# code...
				if($videos = $this->video_m->searchVideo($key)){

					//$infos[] = $videos;
					foreach ($videos as $value) {
						# code...
						if($keys){
							if(in_array($value->video_id, $keys)){

							}else{

							$infos[] = $value;
							}
						}else{

						$infos[] = $value;
						}
						

						$keys[] = $value->video_id;
					}

					}
				}




			echo json_encode(array('stats'=>true,'msg'=>$infos));

			/*if($video = $this->video_m->searchVideo($key)){
			echo json_encode(array('stats'=>true,'msg'=>$video));
				}
		}
			else{

			echo json_encode(array('stats'=>false,'msg'=>'No existing video found'));
			}*/
		}
	}








}

